document.addEventListener('DOMContentLoaded', ()=>{
  const audio = new Audio('assets/bgm/BGM.m4a');
  audio.loop = true;
  audio.volume = 0.8;
  audio.play().catch(()=>{console.log('自动播放可能被浏览器阻止');});
  const confirmBtn = document.getElementById('confirm-btn');
  const customBtn = document.getElementById('custom-btn');
  confirmBtn?.addEventListener('click', ()=>{
    document.getElementById('first-screen').style.display='none';
    document.getElementById('second-screen').style.display='flex';
    if(customBtn) customBtn.style.display='none';
  });
  customBtn?.addEventListener('click', ()=>{ location.href = 'custom.html'; });
});
