window.SITE_CONFIG = {
  githubUser: "lly-lly123",
  githubPAT: "",
  repo: "sturdy-dollop",
  statisticsPath: "data/statistics.json"
};
