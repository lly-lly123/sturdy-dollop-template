
import './config.js';

window.CUSTOM = (function(){
  const images = ["https://picsum.photos/id/1/1600/900", "https://picsum.photos/id/2/1600/900", "https://picsum.photos/id/3/1600/900", "https://picsum.photos/id/4/1600/900", "https://picsum.photos/id/5/1600/900", "https://picsum.photos/id/6/1600/900", "https://picsum.photos/id/7/1600/900", "https://picsum.photos/id/8/1600/900", "https://picsum.photos/id/9/1600/900", "https://picsum.photos/id/10/1600/900", "https://picsum.photos/id/11/1600/900", "https://picsum.photos/id/12/1600/900", "https://picsum.photos/id/13/1600/900", "https://picsum.photos/id/14/1600/900", "https://picsum.photos/id/15/1600/900", "https://picsum.photos/id/16/1600/900", "https://picsum.photos/id/17/1600/900", "https://picsum.photos/id/18/1600/900", "https://picsum.photos/id/19/1600/900", "https://picsum.photos/id/20/1600/900", "https://picsum.photos/id/21/1600/900", "https://picsum.photos/id/22/1600/900", "https://picsum.photos/id/23/1600/900", "https://picsum.photos/id/24/1600/900", "https://picsum.photos/id/25/1600/900", "https://picsum.photos/id/26/1600/900", "https://picsum.photos/id/27/1600/900", "https://picsum.photos/id/28/1600/900", "https://picsum.photos/id/29/1600/900", "https://picsum.photos/id/30/1600/900", "https://picsum.photos/id/31/1600/900", "https://picsum.photos/id/32/1600/900", "https://picsum.photos/id/33/1600/900", "https://picsum.photos/id/34/1600/900", "https://picsum.photos/id/35/1600/900", "https://picsum.photos/id/36/1600/900", "https://picsum.photos/id/37/1600/900", "https://picsum.photos/id/38/1600/900", "https://picsum.photos/id/39/1600/900", "https://picsum.photos/id/40/1600/900", "https://picsum.photos/id/41/1600/900", "https://picsum.photos/id/42/1600/900", "https://picsum.photos/id/43/1600/900", "https://picsum.photos/id/44/1600/900", "https://picsum.photos/id/45/1600/900", "https://picsum.photos/id/46/1600/900", "https://picsum.photos/id/47/1600/900", "https://picsum.photos/id/48/1600/900", "https://picsum.photos/id/49/1600/900", "https://picsum.photos/id/50/1600/900"];
  const bgms = ["assets/bgm/BGM.m4a", "https://freepd.com/music/Track1.mp3", "https://freepd.com/music/Track2.mp3", "https://freepd.com/music/Track3.mp3", "https://freepd.com/music/Track4.mp3", "https://freepd.com/music/Track5.mp3", "https://freepd.com/music/Track6.mp3", "https://freepd.com/music/Track7.mp3", "https://freepd.com/music/Track8.mp3", "https://freepd.com/music/Track9.mp3", "https://freepd.com/music/Track10.mp3", "https://freepd.com/music/Track11.mp3", "https://freepd.com/music/Track12.mp3", "https://freepd.com/music/Track13.mp3", "https://freepd.com/music/Track14.mp3", "https://freepd.com/music/Track15.mp3", "https://freepd.com/music/Track16.mp3", "https://freepd.com/music/Track17.mp3", "https://freepd.com/music/Track18.mp3", "https://freepd.com/music/Track19.mp3", "https://freepd.com/music/Track20.mp3", "https://freepd.com/music/Track21.mp3", "https://freepd.com/music/Track22.mp3", "https://freepd.com/music/Track23.mp3", "https://freepd.com/music/Track24.mp3", "https://freepd.com/music/Track25.mp3", "https://freepd.com/music/Track26.mp3", "https://freepd.com/music/Track27.mp3", "https://freepd.com/music/Track28.mp3", "https://freepd.com/music/Track29.mp3", "https://freepd.com/music/Track30.mp3", "https://freepd.com/music/Track31.mp3", "https://freepd.com/music/Track32.mp3", "https://freepd.com/music/Track33.mp3", "https://freepd.com/music/Track34.mp3", "https://freepd.com/music/Track35.mp3", "https://freepd.com/music/Track36.mp3", "https://freepd.com/music/Track37.mp3", "https://freepd.com/music/Track38.mp3", "https://freepd.com/music/Track39.mp3", "https://freepd.com/music/Track40.mp3", "https://freepd.com/music/Track41.mp3", "https://freepd.com/music/Track42.mp3", "https://freepd.com/music/Track43.mp3", "https://freepd.com/music/Track44.mp3", "https://freepd.com/music/Track45.mp3", "https://freepd.com/music/Track46.mp3", "https://freepd.com/music/Track47.mp3", "https://freepd.com/music/Track48.mp3", "https://freepd.com/music/Track49.mp3", "https://freepd.com/music/Track50.mp3"];
  let selection = {};

  function init(){
    const bgmContainer = document.getElementById('bgm-list');
    bgms.forEach((u,i)=>{
      const el = document.createElement('div');
      el.className='bgm-item';
      el.innerHTML = `<span>{i==0?'默认BGM':'Track '+i}</span> <audio controls src="${u}"></audio> <button data-url="${u}">选择</button>`;
      bgmContainer.appendChild(el);
      el.querySelector('button').addEventListener('click', ()=>{ selection.bgm = u; document.getElementById('bgm-selected').textContent = '已选择BGM：'+(i==0?'默认BGM':'Track '+i); });
    });

    document.getElementById('upload-bgm').addEventListener('change', (e)=>{
      const f=e.target.files[0];if(!f)return;const reader=new FileReader();
      reader.onload=(ev)=>{selection.bgm=ev.target.result;document.getElementById('bgm-selected').textContent='已上传自定义BGM';};
      reader.readAsDataURL(f);
    });

    document.getElementById('ai-gen').addEventListener('click',()=>{document.getElementById('popup-text').value=pseudoGenerate(3);});
    document.getElementById('generate-btn').addEventListener('click',()=>{
      const popup=document.getElementById('popup-text').value;
      const name=document.getElementById('name-text').value||'name';
      const hide=document.getElementById('hide-name').checked;
      const bgm=selection.bgm||'assets/bgm/BGM.m4a';
      const html=`<!doctype html><html lang='zh-CN'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>定制页面</title><style>body{background:#000;color:#fff;text-align:center;padding-top:20%;font-family:PingFang SC}</style></head><body><h2>${popup}</h2><audio autoplay loop src='${bgm}'></audio><div>${hide?'':name}</div><button onclick="location.href='custom.html'" style='margin-top:20px'>定制</button></body></html>`;
      const blob=new Blob([html],{type:'text/html'});
      const url=URL.createObjectURL(blob);
      const a=document.createElement('a');a.href=url;a.download='my_custom_page.html';a.click();
      setTimeout(()=>URL.revokeObjectURL(url),2000);
      alert('已生成网页文件，浏览器将下载');
    });
  }
  return {init};
})();

document.addEventListener('DOMContentLoaded',()=>{window.CUSTOM.init();});
