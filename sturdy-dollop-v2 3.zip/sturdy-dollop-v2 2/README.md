# sturdy-dollop-v2

包含默认本地 BGM 配置的新版网站。

## 使用方法

1. 将你的本地音乐文件命名为 **BGM.m4a**
2. 放入路径： `assets/bgm/BGM.m4a`
3. 上传整个项目到 GitHub 仓库（例如 `lly-lly123/sturdy-dollop`）
4. 在仓库设置中启用 GitHub Pages

网页将自动播放此 BGM。
用户在定制页面中可以选择保留此音乐或更换为在线音乐/上传文件。

若文件未上传，浏览器会提示找不到音频。
